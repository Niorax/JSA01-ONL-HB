
const button = document.getElementsByClassName("button");
button[0].onclick = function(){
    alert("Đã thêm vào giỏ hàng");
}
